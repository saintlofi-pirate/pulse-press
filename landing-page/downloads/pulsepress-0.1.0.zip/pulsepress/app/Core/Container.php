<?php
declare(strict_types=1);

namespace PulsePress\Core;

use Closure;
use ReflectionClass;
use ReflectionException;
use ReflectionNamedType;
use RuntimeException;

class Container
{
    /** @var array<string, array{concrete: mixed, shared: bool}> */
    protected array $bindings = [];

    /** @var array<string, mixed> */
    protected array $instances = [];

    public function bind(string $abstract, $concrete = null, bool $shared = false): void
    {
        $this->bindings[$abstract] = [
            'concrete' => $concrete ?? $abstract,
            'shared'   => $shared,
        ];
    }

    public function singleton(string $abstract, $concrete = null): void
    {
        $this->bind($abstract, $concrete, true);
    }

    public function instance(string $abstract, $instance): void
    {
        $this->instances[$abstract] = $instance;
    }

    public function has(string $id): bool
    {
        return isset($this->bindings[$id]) || isset($this->instances[$id]);
    }

    public function get(string $id)
    {
        if (isset($this->instances[$id])) {
            return $this->instances[$id];
        }

        $concrete = $this->bindings[$id]['concrete'] ?? $id;
        $object   = $this->build($concrete);

        if (($this->bindings[$id]['shared'] ?? false) === true) {
            $this->instances[$id] = $object;
        }

        return $object;
    }

    public function make(string $abstract)
    {
        return $this->get($abstract);
    }

    protected function build($concrete)
    {
        if ($concrete instanceof Closure) {
            return $concrete($this);
        }

        if (!is_string($concrete) || !class_exists($concrete)) {
            throw new RuntimeException(sprintf('Target [%s] is not buildable.', is_string($concrete) ? $concrete : gettype($concrete)));
        }

        try {
            $reflector = new ReflectionClass($concrete);
        } catch (ReflectionException $e) {
            throw new RuntimeException(sprintf('Cannot reflect [%s]: %s', $concrete, $e->getMessage()), 0, $e);
        }

        if (!$reflector->isInstantiable()) {
            throw new RuntimeException(sprintf('Class [%s] is not instantiable.', $concrete));
        }

        $constructor = $reflector->getConstructor();

        if ($constructor === null) {
            return new $concrete();
        }

        $dependencies = [];
        foreach ($constructor->getParameters() as $parameter) {
            $type = $parameter->getType();

            if ($type instanceof ReflectionNamedType && !$type->isBuiltin()) {
                $dependencies[] = $this->get($type->getName());
                continue;
            }

            if ($parameter->isDefaultValueAvailable()) {
                $dependencies[] = $parameter->getDefaultValue();
                continue;
            }

            throw new RuntimeException(sprintf(
                'Cannot resolve parameter [$%s] of [%s::__construct()].',
                $parameter->getName(),
                $concrete
            ));
        }

        return $reflector->newInstanceArgs($dependencies);
    }
}
